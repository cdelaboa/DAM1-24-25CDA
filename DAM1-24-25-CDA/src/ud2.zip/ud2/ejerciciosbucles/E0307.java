package ud2.ejerciciosbucles;
import java.util.*;
public class E0307 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
    /*Escribir todos los múltiplos de 7 menores que 100.*/
      System.out.println("Vamos a escribir todos los múltiplos de 7 ");
        int i, n;
      for (n = 0; n < 12; n++) {
        for (i = 7; i < 100; i = 7 * n) { System.out.println("Los múltiplos de 7 son" + i);
   
            
    
   
        }  
        sc.close();
    }}
    }
    



 






    

