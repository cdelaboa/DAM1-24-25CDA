package ud2.ejerciciosbucles;

import java.util.Scanner;

public class E0406 {
public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    /*Diseñar una función con el siguiente prototipo:
    boolean esPrimo(int n)
    que devolverá true si n es primo y false en caso contrario.
     */

     System.out.println("");
}
}
