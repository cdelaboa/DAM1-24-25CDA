package ud1.exercicios.CDA20241004;

import java.util.Scanner;

public class EP0123 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       //Programa: Escribe un programa que convierta unidades de masa entre kilogramos y 
       //libras o viceversa. El programa solicitará al usuario la cantidad de masa
        //y la unidad de medida origen (kilogramos o libras)
         

        //Datos
        final double kGramos = 1000;
        final double libras = 453.592;


        System.out.println("Dime la cantidad de masa que quieres transformar");
        double cantidad = scanner.nextDouble();
        System.out.println("Ahora dime en qué medida lo quieres");
        double medida = scanner.nextDouble();
         
        


        
            
     














        scanner.close();

    }
}
